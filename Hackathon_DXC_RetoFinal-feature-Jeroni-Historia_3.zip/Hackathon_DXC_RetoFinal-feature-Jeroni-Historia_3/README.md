"# Hackathon_DXC_RetoFinal [Equipo 2]" 

Branch Jeroni Paul

Historias de usuario implementadas:

❑ 3. Como usuario, quiero poder añadir nuevos presupuestos (Budget) por categoría para poder decidir cuál es la mejor opción para un gasto.

❑ 8. Como usuario, quiero observar el cumplimiento de mis objetivos financieros mensualmente para tomar decisiones más acertadas.
