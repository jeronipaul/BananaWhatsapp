package com.banana.bananamint.persistence;

import com.banana.bananamint.domain.Budget;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public interface BudgetJPARepository  extends JpaRepository<Budget, Long> {
    @Query("SELECT p FROM Budget p WHERE p.user.id = ?1")
    public List<Budget> findAll(Long idCustomer) throws SQLException;

    public List<Budget> findByUserIdAndCategoryName(Long idCustomer, String categoryName) throws SQLException;

    public Optional<Budget> findByUserIdAndId(Long idCustomer, Long idBudget) throws SQLException;

    //public Budget save(Budget budget);
}
