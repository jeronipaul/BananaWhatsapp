package com.banana.bananamint.services;

import com.banana.bananamint.domain.Customer;
import com.banana.bananamint.domain.Goal;
import com.banana.bananamint.exception.BudgetException;
import com.banana.bananamint.exception.CustomerNotFoundException;
import com.banana.bananamint.exception.GoalException;
import com.banana.bananamint.payload.Debt;
import com.banana.bananamint.payload.GoalApproximation;
import com.banana.bananamint.persistence.GoalJPARepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Service
public class GoalServiceImpl implements GoalService {
    @Autowired
    private GoalJPARepository repo;

    @Override
    public List<Goal> showAll(Long idCustomer) throws GoalException {
        try {
            List<Goal> lista = repo.findAllByCustomerId(idCustomer);
            if (lista.size() > 0)
                return lista;
            else
                throw new GoalException("Selection criteria yelds no records");
        } catch (SQLException e) {
            throw new GoalException("Internal database error");
        }
    }

    @Override
    public List<Goal> add(Long idCustomer, Goal goal) throws GoalException {
                /* Search the category */
        /* Create the budget */
        goal.setUser(new Customer(idCustomer));
        try {
            repo.save(goal);
        } catch(DataIntegrityViolationException e) {
            throw new CustomerNotFoundException("Incorrect user, goal not created");
        }

        try {
            return repo.findAllByCustomerId(idCustomer);
        } catch (SQLException e) {
            throw new GoalException("Internal database error");
        }
    }

    @Override
    public List<GoalApproximation> generateReport(Long idCustomer, LocalDate initDate, LocalDate finalDate) throws GoalException {
        try {
            List<Goal> lista = repo.findByCustomerAndDate(idCustomer, initDate, finalDate);
            if (lista.size() > 0) {
                List<GoalApproximation> result = new ArrayList<>();
                for (Goal g:lista) {
                    result.add(new GoalApproximation(g,g.getTargetAmount(),0,LocalDate.now()));
                }
                return result;
            }
            else
                throw new GoalException("Selection criteria yelds no records");
        } catch (SQLException e) {
            throw new GoalException("Internal database error");
        }
    }

    @Override
    public List<Debt> accumulatedDebt(Long idCustomer, LocalDate initDate, LocalDate finalDate) throws GoalException {
        return null;
    }
}
