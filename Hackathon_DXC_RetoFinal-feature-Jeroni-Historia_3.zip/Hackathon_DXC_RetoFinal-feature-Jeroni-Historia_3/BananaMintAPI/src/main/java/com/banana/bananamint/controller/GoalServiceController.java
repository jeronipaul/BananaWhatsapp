package com.banana.bananamint.controller;

import com.banana.bananamint.domain.Goal;
import com.banana.bananamint.exception.BudgetException;
import com.banana.bananamint.domain.Category;
import com.banana.bananamint.domain.Budget;
import com.banana.bananamint.services.GoalService;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.hibernate.validator.constraints.NotBlank;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.Min;
import java.util.List;

@RestController
@RequestMapping("/customers")
@Validated
@Tag(name = "GoalController API", description = "Goal API - browse, create and update goals")

public class GoalServiceController {
    private static final Logger logger = LoggerFactory.getLogger(BudgetServiceController.class);

    @Autowired
    private GoalService goalserv;

    // Method GET (Get goals by customer)
    @Operation(summary = "Get customer goals", description = "Returns all goals with selected customer")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved"),
            @ApiResponse(responseCode = "404", description = "Not Found - The goal was not found"),
            @ApiResponse(responseCode = "422", description = "Unprocessable Entity")
    })
    @GetMapping(value = "/{id}/goals", produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<List<Goal>> getGoalByName(
            @Parameter(name = "id", description = "Customer id", example = "1", required = true)
            @PathVariable @Min(1) Long id
    ) {
        try {
            return ResponseEntity.status(HttpStatus.OK).body(goalserv.showAll(id)); // HTTP 200
        } catch (BudgetException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build(); // HTTP 404
        }
    }

    // Método POST (Crear nuevo presupuesto)
    @Operation(summary = "Create a new goal", description = "Create a new goal")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Created"),
            @ApiResponse(responseCode = "412", description = "Precondition Failed"),
            @ApiResponse(responseCode = "422", description = "Unprocessable Entity")
    })
    @PostMapping(value = "/{id}/goals", consumes = {MediaType.APPLICATION_JSON_VALUE}, produces = {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity<Goal> createGoal(
            @Parameter(name = "id", description = "Customer id", example = "1", required = true)
            @PathVariable @Min(1) Long id,
            @RequestBody @Valid Goal newGoal) {
        logger.info("newGoal:" + newGoal);
        return new ResponseEntity<>(goalserv.add(id, newGoal).get(1), HttpStatus.CREATED); // HTTP 201
    }

}
