package com.banana.bananamint.exception;

public class CategoryException extends RuntimeException{
    public CategoryException() {
    }

    public CategoryException(String message) {
        super(message);
    }
}
