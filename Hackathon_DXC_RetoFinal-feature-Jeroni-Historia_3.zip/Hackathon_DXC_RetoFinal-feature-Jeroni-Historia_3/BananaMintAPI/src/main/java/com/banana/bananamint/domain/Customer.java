package com.banana.bananamint.domain;


import com.banana.bananamint.exception.CustomerException;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "customer")
@Schema(name = "Customer", description = "Modelo customer (Cliente)")
public class Customer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String email;
    private LocalDate birthDate;
    private String dni;

    public boolean isValid() throws CustomerException {
        // Para que el usuario sea válido:
        // email válido
        // mayor de 18 años
        // dni: 8_Números + 1_Letra
        // Si no es válido, debe lanzar exception

        return false;
    }

    public Customer(Long uid) {
        id = uid;
    }

}
