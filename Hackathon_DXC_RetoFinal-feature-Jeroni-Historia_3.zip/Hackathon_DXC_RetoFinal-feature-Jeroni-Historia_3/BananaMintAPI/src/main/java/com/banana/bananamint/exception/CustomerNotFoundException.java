package com.banana.bananamint.exception;

public class CustomerNotFoundException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    public CustomerNotFoundException() {
        super("Customer not found");
    }

    public CustomerNotFoundException(Long customerId) {
        super("Customer with id: " + customerId + " not found");
    }


    public CustomerNotFoundException(String message) {
        super(message);
    }
}
