package com.banana.bananamint.persistence;

import com.banana.bananamint.domain.Category;
import org.springframework.data.jpa.repository.JpaRepository;

import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public interface CategoryJPARepository extends JpaRepository<Category, Integer> {
    //public List<Category> findAll() throws SQLException;

    //public Category save(Category category) throws SQLException;

    public Optional<Category> findByName(String name) throws SQLException;
}
