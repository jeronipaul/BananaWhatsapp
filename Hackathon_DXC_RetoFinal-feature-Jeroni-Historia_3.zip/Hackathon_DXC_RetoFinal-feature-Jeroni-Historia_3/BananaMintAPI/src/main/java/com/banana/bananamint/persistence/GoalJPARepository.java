package com.banana.bananamint.persistence;

import com.banana.bananamint.domain.Goal;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

public interface GoalJPARepository  extends JpaRepository<Goal, Long> {
    @Query("SELECT p FROM Goal p WHERE p.user.id = ?1")
    public List<Goal> findAllByCustomerId(Long idCustomer) throws SQLException;

    //public Goal dave(Goal goal) throws SQLException;

    @Query("SELECT p FROM Goal p WHERE p.user.id = ?1 AND p.targetDate BETWEEN ?2 AND ?3")
    public List<Goal> findByCustomerAndDate(Long idCustomer, LocalDate initDate, LocalDate finalDate) throws SQLException;
}
