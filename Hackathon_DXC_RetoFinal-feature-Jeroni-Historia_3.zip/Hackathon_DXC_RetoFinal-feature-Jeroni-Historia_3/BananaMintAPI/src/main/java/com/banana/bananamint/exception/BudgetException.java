package com.banana.bananamint.exception;

public class BudgetException extends RuntimeException{
    private static final long serialVersionUID = 1L;
    public BudgetException() { super("Budget not found");
    }

    public BudgetException(String message) {
        super(message);
    }
}
