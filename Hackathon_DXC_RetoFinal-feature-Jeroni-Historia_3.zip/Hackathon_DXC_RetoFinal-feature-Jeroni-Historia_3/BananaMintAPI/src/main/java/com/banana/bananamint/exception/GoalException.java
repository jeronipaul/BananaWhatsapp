package com.banana.bananamint.exception;

public class GoalException extends RuntimeException{
    public GoalException() {
    }

    public GoalException(String message) {
        super(message);
    }
}
