package com.banana.bananamint.services;

import com.banana.bananamint.domain.Budget;
import com.banana.bananamint.domain.Category;
import com.banana.bananamint.domain.Customer;
import com.banana.bananamint.exception.BudgetException;
import com.banana.bananamint.exception.CustomerNotFoundException;
import com.banana.bananamint.persistence.BudgetJPARepository;
import com.banana.bananamint.persistence.CategoryJPARepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import java.sql.SQLException;
import java.util.List;

@Service
public class BudgetServiceImpl implements BudgetService {
    @Autowired
    private BudgetJPARepository repo;
    @Autowired
    private CategoryJPARepository repoCategory;

    @Override
    public List<Budget> showAll(Long idCustomer, String categoryName) throws BudgetException {
        try {
            List<Budget> lista = repo.findByUserIdAndCategoryName(idCustomer, categoryName);
            if (lista.size() > 0)
                return lista;
            else
                throw new BudgetException("Selection criteria yelds no records");
        } catch (SQLException e) {
            throw new BudgetException("Internal database error");
        }
    }

    @Override
    public Budget showBudget(Long idCustomer, Long idBudget) throws BudgetException {
        try {
            return repo.findByUserIdAndId(idCustomer, idBudget)
                    .orElseThrow(() -> new BudgetException("Selection criteria yelds no records"));
        } catch (SQLException e) {
            throw new BudgetException("Internal database error");
        }
    }

    @Override
    public Budget add(Long idCustomer, String categoryName, double amount) throws BudgetException {
        /* Search the category */
        Category cat;
        try {
            cat = repoCategory.findByName(categoryName)
                    .orElseThrow(() -> new BudgetException("Incorrect category, budget not created"));
        } catch(SQLException e) {
            throw new BudgetException("Internal database error");
        }

        /* Create the budget */
        Budget newbudget = new Budget(null, cat, amount,
               new Customer(idCustomer), 0L, 0L);
        try {
            repo.save(newbudget);
        } catch(DataIntegrityViolationException e) {
            throw new CustomerNotFoundException("Incorrect user, budget not created");
        }

        return newbudget;
    }
}
