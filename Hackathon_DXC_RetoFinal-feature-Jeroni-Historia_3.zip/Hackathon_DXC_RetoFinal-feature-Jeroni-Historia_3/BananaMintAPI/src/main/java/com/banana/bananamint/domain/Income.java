package com.banana.bananamint.domain;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "income")
@Schema(name = "Income", description = "Modelo income (Ingreso)")
public class Income {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer Id;

    @Transient
    private Customer user;

    private double amount;

    private LocalDate enterDate;

    @Transient
    private Account moneyTo;

    private String status;

}
