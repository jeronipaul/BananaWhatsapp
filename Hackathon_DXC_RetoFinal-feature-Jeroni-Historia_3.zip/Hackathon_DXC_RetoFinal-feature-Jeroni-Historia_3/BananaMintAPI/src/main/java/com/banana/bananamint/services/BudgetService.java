package com.banana.bananamint.services;

import com.banana.bananamint.domain.Budget;
import com.banana.bananamint.exception.BudgetException;
import org.springframework.stereotype.Service;

import java.util.List;

public interface BudgetService {
    public List<Budget> showAll(Long idCustomer, String categoryName) throws BudgetException;

    public Budget showBudget(Long idCustomer, Long idBudget) throws BudgetException;

    public Budget add(Long idCustomer, String categoryName, double amount) throws BudgetException;
}
