package com.banana.bananamint.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDate;

//@data - Generará automáticamente los métodos equals, hashCode, toString y getters/setters para todas las propiedades de la clase.
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "accounts")
@Schema(name = "Account", description = "Modelo account (Cuenta)")
public class Account {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String type;

    LocalDate openingDate;

    private double balance;

    private double maxOverdraft;

    //@Transient
    @ManyToOne
    @JoinColumn(name = "customer_id")
    @JsonIgnore
    private Customer owner;

    private boolean active;

}
