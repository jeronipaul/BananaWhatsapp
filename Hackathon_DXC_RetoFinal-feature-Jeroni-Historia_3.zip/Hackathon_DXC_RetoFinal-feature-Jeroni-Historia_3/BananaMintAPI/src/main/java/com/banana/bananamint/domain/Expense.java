package com.banana.bananamint.domain;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "expense")
@Schema(name = "Expense", description = "Modelo expense (Gastos)")
public class Expense {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer Id;

    @Transient
    private Customer user;

    private double amount;

    private LocalDate dueDate;

    @Transient
    private Account moneyFrom;

    private String status;

}
