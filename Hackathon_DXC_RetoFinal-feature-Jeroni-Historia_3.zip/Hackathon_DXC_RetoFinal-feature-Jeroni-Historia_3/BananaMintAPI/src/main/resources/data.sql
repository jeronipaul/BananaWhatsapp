INSERT INTO customer (name, email, birth_date, dni) VALUES
('Alexandru','alex@bananamint.com','1981-03-06','12345678L'),
('Jeroni','jeroni@bananamint.com','1982-03-06','22345678L'),
('Ernest','ernest@bananamint.com','1983-03-06','32345678L'),
('Ricardo','ricahu@bananamint.com','1984-03-06','42345678L'),
('Juanjo','jjpd@bananamint.com','1985-03-06','52345678L');

INSERT INTO category (name, type, description, created_at) VALUES
('Obras', 'Construccion', 'Mejora de locales', '2023-01-03'),
('Electrodomésticos', 'Hogar', 'Adquisición de electrodomésticos', '2023-01-05');

INSERT INTO budget (amount, balance, selected, category_id, customer_id) VALUES
(1000, 50000, 100, 1, 2),
(2000, 30000, 150, 1, 2),
(5000, 40000, 200, 2, 4);

INSERT INTO goal (name, description, target_amount, status, target_date, customer_id) VALUES
('Ahorro', 'Ahorro 30€ mensuales', 30, 'Done', '2023-05-01', 2),
('Ahorro', 'Reducción gastos', 20, 'In progress', '2024-09-01', 2),
('Inversión', 'Inversión mensual', 50, 'Pending', '2024-12-01', 4);
