package com.banana.bananamint.services;

import com.banana.bananamint.domain.Customer;
import com.banana.bananamint.domain.Goal;
import com.banana.bananamint.exception.CustomerNotFoundException;
import com.banana.bananamint.exception.GoalException;
import com.banana.bananamint.payload.GoalApproximation;
import com.banana.bananamint.persistence.GoalJPARepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.LocalDate;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class GoalServiceImplTest {
    @Autowired
    private GoalJPARepository repo;
    @Autowired
    private GoalService serv;

    @Test
    void givenCustomer_whenValid_thenListOK() {
        List<Goal> lista = serv.showAll(2L);
        System.out.println(lista);
        assertThat(lista.size(), greaterThan(1));
    }

    @Test
    void givenCustomer_whenInvalid_thenException() {
        assertThrows(GoalException.class, () -> {
                    serv.showAll(9L);
                });
    }

    @Test
    void givenNewGoal_whenValid_thenSavedOK() {
        Goal newGoal = new Goal(null, "Futuro", "Planes de pensiones", 100, "Pending", LocalDate.now(),
                new Customer(1L));
        List<Goal> listGoal = serv.add(1L, newGoal);

        Goal modGoal = repo.findById(listGoal.get(listGoal.size() - 1).getId()).get();
        assertThat(modGoal.getName(), is("Futuro"));
        System.out.println(modGoal);
    }

    @Test
    void givenNewGoal_whenInvalid_thenException() {
        Goal newGoal = new Goal(null, "Futuro", "Planes de pensiones", 100, "Pending", LocalDate.now(),
                new Customer(9L));
        assertThrows(CustomerNotFoundException.class, () -> {
            List<Goal> listGoal = serv.add(9L, newGoal);
        } );

    }

    @Test
    void givenCustomerAndDates_whenValid_thenReportOK() {
        List<GoalApproximation> obj = serv.generateReport(2L, LocalDate.of(2024, 01, 01), LocalDate.of(2024, 12, 31));
        System.out.println(obj);
        assertThat(obj.size(), greaterThan(0));
    }

    @Test
    void givenCustomerAndDates_whenInvalid_thenException() {
        assertThrows(GoalException.class, () -> {
            List<GoalApproximation> obj = serv.generateReport(9L, LocalDate.of(2024, 01, 01), LocalDate.of(2024, 12, 31));
        });
    }
}