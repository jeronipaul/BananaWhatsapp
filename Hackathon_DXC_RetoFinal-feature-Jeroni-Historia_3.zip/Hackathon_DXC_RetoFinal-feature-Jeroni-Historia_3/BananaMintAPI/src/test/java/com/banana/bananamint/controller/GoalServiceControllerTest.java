package com.banana.bananamint.controller;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

import com.banana.bananamint.domain.Goal;
import com.banana.bananamint.domain.Customer;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.time.LocalDate;

import static com.banana.bananamint.util.JsonUtil.asJsonString;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@AutoConfigureMockMvc


class GoalServiceControllerTest {
    @Autowired
    private MockMvc mvc;

    @Test
    void givenUser_whenValid_thenList() throws Exception {
        mvc.perform(get("/customers/2/goals").contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$[*].name", hasItem("Ahorro")));
    }

    @Test
    void givenUser_whenInvalid_thenError() throws Exception {
        mvc.perform(get("/customers/9/goals").contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
    }

    @Test
    void givenUserAndGoal_whenValid_thenSaved() throws Exception {
        mvc.perform( MockMvcRequestBuilders
              .post("/customers/2/goals")
              .content(asJsonString(new Goal(null, "Futuro", "Aportación plan pensiones",
                      111.0, "Pending", LocalDate.now(), new Customer(2L))))
              .contentType(MediaType.APPLICATION_JSON)
              .accept(MediaType.APPLICATION_JSON))
          .andExpect(status().isCreated())
          .andExpect(MockMvcResultMatchers.jsonPath("id").exists());
    }

    @Test
    void givenUserAndGoal_whenInvalid_thenError() throws Exception {
        mvc.perform( MockMvcRequestBuilders
              .post("/customers/9/goals")
              .content(asJsonString(new Goal(null, "Futuro", "Aportación plan pensiones",
                      111.0, "Pending", LocalDate.now(), new Customer(9L))))
              .contentType(MediaType.APPLICATION_JSON)
              .accept(MediaType.APPLICATION_JSON))
          .andExpect(status().is4xxClientError());
    }
}