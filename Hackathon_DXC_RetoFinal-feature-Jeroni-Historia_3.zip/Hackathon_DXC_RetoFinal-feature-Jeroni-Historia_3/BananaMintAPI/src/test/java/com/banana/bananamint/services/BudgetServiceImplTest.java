package com.banana.bananamint.services;

import com.banana.bananamint.exception.BudgetException;
import com.banana.bananamint.persistence.BudgetJPARepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import com.banana.bananamint.domain.Budget;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.Matchers.is;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class BudgetServiceImplTest {
    @Autowired
    private BudgetJPARepository repo;
    @Autowired
    private BudgetService serv;

    @Test
    void givenCustomerAndCategory_whenValid_thenListOK() {
        List<Budget> lista = serv.showAll(2L, "Obras");
        System.out.println(lista);
        assertThat(lista.size(), greaterThan(1));
    }

    @Test
    void givenCustomerAndCategory_whenInvalid_thenException() {
        assertThrows(BudgetException.class, () -> {
            serv.showAll(2L, "Otros"); });
    }

    @Test
    void givenNewBudget_whenValid_thenSavedOK() {
        Budget newBudget = serv.add(1L, "Obras", 1234);

        Budget modBudget = repo.findById(newBudget.getId()).get();
        assertThat(modBudget.getAmount(), is(1234.0));
        System.out.println(modBudget);
    }

    @Test
    void givenNewBudget_whenInvalid_thenException() {
        assertThrows(BudgetException.class, () -> {
        Budget newBudget = serv.add(1L, "Otros", 1234); } );

    }
}