package com.banana.bananamint.persistence;

import com.banana.bananamint.domain.Budget;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.sql.SQLException;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class BudgetJPARepositoryTest {
    @Autowired
    private BudgetJPARepository repo;

    @Test
    void givenCustomer_whenValid_thenBudgetList() throws SQLException {
        List<Budget> lista = repo.findAll(2L);
        System.out.println(lista);
        assertThat(lista.size(), greaterThan(1));
    }

    @Test
    void givenCustomerAndCategory_whenValid_thenOK() throws SQLException {
        List<Budget> lista = repo.findByUserIdAndCategoryName(2L, "Obras");
        assertThat(lista.size(), is(2));
        assertThat(lista.get(0).getUser().getName(), is("Jeroni"));
    }

    @Test
    void givenNewBudget_whenValid_thenSavedOK() throws SQLException {
        Budget newBudget = repo.findById(1L).get();
        //Check that budget data is saved but user data is not
        newBudget.setAmount(1234);  // Data saved
        newBudget.getUser().setName("Prueba");  // Data not saved
        repo.save(newBudget);

        Budget modBudget = repo.findById(1L).get();
        assertThat(modBudget.getAmount(), is(1234.0));
        assertThat(modBudget.getUser().getName(), is("Jeroni"));
        System.out.println(modBudget);
    }
}