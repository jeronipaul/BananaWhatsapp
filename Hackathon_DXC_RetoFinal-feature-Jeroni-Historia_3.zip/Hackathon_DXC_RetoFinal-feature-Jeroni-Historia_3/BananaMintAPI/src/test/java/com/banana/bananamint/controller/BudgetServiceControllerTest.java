package com.banana.bananamint.controller;

import com.banana.bananamint.domain.Budget;
import com.banana.bananamint.domain.Category;
import com.banana.bananamint.domain.Customer;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.time.LocalDate;

import static com.banana.bananamint.util.JsonUtil.asJsonString;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@AutoConfigureMockMvc
class BudgetServiceControllerTest {
    @Autowired
    private MockMvc mvc;

    @Test
    void givenUserAndBudgetId_whenValid_ThenOK() throws Exception {
        mvc.perform(get("/customers/2/budget/2").contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$[*].name", hasItem("Obras")));
    }

    @Test
    void givenUserAndBudgetId_whenInvalid_ThenError() throws Exception {
        mvc.perform(get("/customers/2/budget/9").contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                ;
    }

    @Test
    void givenUserAndCategoryName_whenValid_ThenOK() throws Exception {
        mvc.perform(get("/customers/2/budgets/Obras").contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$[*].amount", hasItem(1000.0)));
    }

    @Test
    void givenUserAndCategoryName_whenInvalid_ThenError() throws Exception {
        mvc.perform(get("/customers/2/budgets/Otros").contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                ;
    }

    @Test
    void givenUserAndBudget_whenValid_ThenSaved() throws Exception {
      mvc.perform( MockMvcRequestBuilders
              .post("/customers/2/budgets")
              .content(asJsonString(new Budget(null,
                      new Category(1, "Obras", "Construcción", "Mejora de locales", LocalDate.now()),
                      2111.0, new Customer(2L), 151L, 30001L)))
              .contentType(MediaType.APPLICATION_JSON)
              .accept(MediaType.APPLICATION_JSON))
          .andExpect(status().isCreated())
          .andExpect(MockMvcResultMatchers.jsonPath("id").exists());
    }

    @Test
    void givenUserAndBudget_whenInvalid_ThenError() throws Exception {
      mvc.perform( MockMvcRequestBuilders
              .post("/customers/2/budgets")
              .content(asJsonString(new Budget(null,
                      new Category(1, "Otros", "Construcción", "Mejora de locales", LocalDate.now()),
                      2111.0, new Customer(2L), 151L, 30001L)))
              .contentType(MediaType.APPLICATION_JSON)
              .accept(MediaType.APPLICATION_JSON))
          .andExpect(status().is4xxClientError());
    }
}