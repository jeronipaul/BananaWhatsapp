package com.banana.bananamint.persistence;

import com.banana.bananamint.domain.Goal;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class GoalJPARepositoryTest {
    @Autowired
    private GoalJPARepository repo;

    @Test
    void givenCustomer_whenValid_thenGoalList() throws SQLException {
        List<Goal> lista = repo.findAllByCustomerId(2L);
        assertThat(lista.size(), is(2));
        assertThat(lista.get(0).getUser().getName(), is("Jeroni"));
    }

    @Test
    void givenCustomerAndDataRange_whenValid_thenOK() throws SQLException {
        List<Goal> lista = repo.findByCustomerAndDate(2L, LocalDate.of(2024, 01, 01), LocalDate.of(2024, 12, 31));
        assertThat(lista.size(), is(1));
        assertThat(lista.get(0).getUser().getName(), is("Jeroni"));
    }

    @Test
    void givenNewGoal_whenValid_thenSavedOK() throws SQLException {
        Goal newGoal = repo.findById(1L).get();
        //Check that budget data is saved but user data is not
        newGoal.setStatus("Done");  // Data saved
        newGoal.getUser().setName("Prueba");  // Data not saved
        repo.save(newGoal);

        Goal modGoal = repo.findById(1L).get();
        assertThat(modGoal.getStatus(), is("Done"));
        assertThat(modGoal.getUser().getName(), is("Jeroni"));
        System.out.println(modGoal);
    }
}