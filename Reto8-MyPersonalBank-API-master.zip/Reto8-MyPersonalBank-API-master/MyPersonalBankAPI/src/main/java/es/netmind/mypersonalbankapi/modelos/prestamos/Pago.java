package es.netmind.mypersonalbankapi.modelos.prestamos;

public class Pago {
}
