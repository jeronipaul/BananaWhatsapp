package es.netmind.mypersonalbankapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyPersonalBankApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
