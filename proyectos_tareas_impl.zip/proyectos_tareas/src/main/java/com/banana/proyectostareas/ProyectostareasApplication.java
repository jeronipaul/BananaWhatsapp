package com.banana.proyectostareas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectostareasApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectostareasApplication.class, args);
	}

}
