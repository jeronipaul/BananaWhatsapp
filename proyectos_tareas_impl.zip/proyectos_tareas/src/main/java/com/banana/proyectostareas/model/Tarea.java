package com.banana.proyectostareas.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import io.swagger.v3.oas.annotations.media.Schema;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor

@Entity
@Schema(name = "Tarea", description = "Modelo tarea")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
public class Tarea {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Min(1)
    @Schema(name = "ID de la tarea", example = "1", required = false)
    private Long id;

    @NotBlank
    @Size(min = 3, max = 30)
    @Schema(name = "Nombre de la tarea", example = "Creación modelo recibo", required = true)
    private String descripcion;

    @Schema(name = "Fecha límite de la tarea", example = "2024-02-21", required = true)
    private LocalDate fechaLimite;

    @Min(1)
    @Schema(name = "Orden de la tarea", example = "1", required = true)
    private Integer orden;

    @Schema(name = "Estado de la tarea", example = "true", required = true)
    private boolean completada;

}
