package com.banana.proyectostareas.controller;

import com.banana.proyectostareas.model.Proyecto;
import com.banana.proyectostareas.exception.ProyectoNotfoundException;
import com.banana.proyectostareas.exception.TareaNotfoundException;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.banana.proyectostareas.service.*;

import java.util.List;

@RestController
@RequestMapping("/proyectos")
@Validated
@Tag(name = "APIGestionProyectos", description = "ProyectosTareas - API proyectos")
public class ProyectoControllerAPI {
    @Autowired
    private ProyectoTareaService servProyecto;

    // Método GET (Obtener Clientes 'getClientes')
    @Operation(summary = "Get all projects", description = "Returns all projects from the application")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved"),
            @ApiResponse(responseCode = "404", description = "Not found - The project was not found")
    })
    @GetMapping(value = "", produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<List<Proyecto>> getProyectos() throws ProyectoNotfoundException {
        List<Proyecto> proyectos = servProyecto.obtenerProyectos();
        if (proyectos != null && proyectos.size() > 0)
            return new ResponseEntity<>(proyectos, HttpStatus.OK); // HTTP 200
            //else return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        else
            throw new ProyectoNotfoundException("La lista de proyectos está vacía"); // HTTP 404
    }
}
