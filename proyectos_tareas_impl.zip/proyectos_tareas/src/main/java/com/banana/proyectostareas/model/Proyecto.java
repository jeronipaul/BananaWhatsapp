package com.banana.proyectostareas.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import io.swagger.v3.oas.annotations.media.Schema;
import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Schema(name = "Proyecto", description = "Modelo proyecto")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
public class Proyecto {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Min(1L)
    @Schema(name = "ID del proyecto", example = "1", required = false)
    private Long id;

    @NotBlank
    @Size(min = 3, max = 30)
    @Schema(name = "Nombre del proyecto", example = "Gestión recibos", required = true)
    private String nombre;

    @Schema(name = "Fecha de alta del proyecto", example = "2024-02-21", required = true)
    private LocalDate fechaCreacion;
}
