--
-- Database: 'proyectosapidb'
--

INSERT INTO proyecto (nombre, fecha_Creacion) VALUES
('Gestión de recibos', '2023-11-07'),
('Histórico de recibos', '2023-11-07'),
('Devolución de recibos', '2023-11-07');

INSERT INTO tarea (descripcion, fecha_Limite, orden, completada) VALUES
('Creacion modelo recibo', '2024-11-07', 1, true);


-- NOTAS:
-- + Si no le indicamos el id, lo genera automáticamente la BB.DD. H2 en función del @Id de la entidad.
-- + Hibernate transforma los nombres de entidades y propiedades a "snake_case" SIEMPRE.
