package com.banana.proyectostareas.persistence;

import com.banana.proyectostareas.model.Proyecto;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.LocalDate;

@SpringBootTest
class ProyectoJPARepositoryTest {
    @Autowired
    private ProyectoJPARepository repoProyecto;

    @Test
    void findAll() {
        System.out.println(repoProyecto.findAll());
    }

    @Test
    void save() {
        Proyecto nuevoProy = new Proyecto(null, "Cancelacion de recibos", LocalDate.now());
        System.out.println(repoProyecto.save(nuevoProy));
        System.out.println(repoProyecto.findById(nuevoProy.getId()));
    }

    //@Test
    //void update() {
    //}
}