package com.banana.proyectostareas.service;

import com.banana.proyectostareas.persistence.ProyectoJPARepository;
import org.junit.jupiter.api.Test;
import com.banana.proyectostareas.model.Proyecto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class ProyectoServiceTest {

    @Autowired
    private ProyectoJPARepository repoProyecto;
    @Autowired
    private ProyectoTareaService servProyecto;

    @Test
    void crearProyecto() {
        Proyecto nuevoProy = new Proyecto(null, "Cancelacion de recibos", LocalDate.now());
        System.out.println(servProyecto.crearProyecto(nuevoProy));
        System.out.println(repoProyecto.findById(nuevoProy.getId()));
    }
}